package com.example.moneyreceipt

import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.exifinterface.media.ExifInterface
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.DateFormat
import java.util.Date

class MainActivity : AppCompatActivity() {

    data class Contact(val name: String, val num: String)

    private val contacts = mutableListOf<Contact>()
    private lateinit var prefs: SharedPreferences

    private lateinit var spinner: Spinner
    private lateinit var editName: EditText
    private lateinit var editNumber: EditText
    private lateinit var editCountry: EditText
    private lateinit var editAmount: EditText
    private lateinit var editCurrency: EditText
    private lateinit var editNote: EditText
    private lateinit var editSerials: EditText
    private lateinit var preview: ImageView
    private lateinit var btnRead: Button
    private lateinit var status: TextView

    private lateinit var photoFile: File
    private lateinit var photoUri: Uri
    private var hasPhoto = false

    private val takePicture =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
            if (ok) {
                hasPhoto = true
                val bmp = loadBitmap(photoFile, 1000)
                preview.setImageBitmap(bmp)
                preview.visibility = View.VISIBLE
                btnRead.visibility = View.VISIBLE
                readSerials()
            }
        }

    private val pickPhone =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val uri = r.data?.data
            if (r.resultCode == RESULT_OK && uri != null) loadPhoneContact(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("money_receipt", MODE_PRIVATE)

        spinner = findViewById(R.id.spinnerContacts)
        editName = findViewById(R.id.editName)
        editNumber = findViewById(R.id.editNumber)
        editCountry = findViewById(R.id.editCountry)
        editAmount = findViewById(R.id.editAmount)
        editCurrency = findViewById(R.id.editCurrency)
        editNote = findViewById(R.id.editNote)
        editSerials = findViewById(R.id.editSerials)
        preview = findViewById(R.id.imagePreview)
        btnRead = findViewById(R.id.btnRead)
        status = findViewById(R.id.textStatus)

        val dir = File(cacheDir, "images").apply { mkdirs() }
        photoFile = File(dir, "photo.jpg")
        photoUri = FileProvider.getUriForFile(this, "$packageName.fileprovider", photoFile)

        editCountry.setText(prefs.getString("country", ""))
        editCurrency.setText(prefs.getString("currency", ""))
        loadContacts()
        refreshSpinner()

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos > 0) {
                    val c = contacts[pos - 1]
                    editName.setText(c.name)
                    editNumber.setText(c.num)
                }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        findViewById<Button>(R.id.btnPickPhone).setOnClickListener {
            pickPhone.launch(
                Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)
            )
        }
        findViewById<Button>(R.id.btnSave).setOnClickListener { saveContact() }
        findViewById<Button>(R.id.btnDelete).setOnClickListener { deleteContact() }
        findViewById<Button>(R.id.btnPhoto).setOnClickListener { takePicture.launch(photoUri) }
        btnRead.setOnClickListener { readSerials() }
        findViewById<Button>(R.id.btnSend).setOnClickListener { sendToWhatsApp() }
    }

    // ---------- Contacts ----------

    private fun loadContacts() {
        contacts.clear()
        try {
            val arr = JSONArray(prefs.getString("contacts", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                contacts.add(Contact(o.getString("name"), o.getString("num")))
            }
        } catch (_: Exception) {
        }
    }

    private fun persistContacts() {
        val arr = JSONArray()
        contacts.forEach { arr.put(JSONObject().put("name", it.name).put("num", it.num)) }
        prefs.edit().putString("contacts", arr.toString()).apply()
    }

    private fun refreshSpinner(select: Int = 0) {
        val labels = mutableListOf(if (contacts.isEmpty()) "No saved contacts yet" else "Choose a saved contact…")
        contacts.forEach { labels.add("${it.name} · ${it.num}") }
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        spinner.setSelection(select)
    }

    private fun loadPhoneContact(uri: Uri) {
        val proj = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        contentResolver.query(uri, proj, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                editName.setText(c.getString(0))
                editNumber.setText(c.getString(1))
                toast("Tap “Save contact” to keep it.")
            }
        }
    }

    private fun normalizedNumber(raw: String): String {
        var n = raw.trim()
        val plus = n.startsWith("+")
        n = n.filter { it.isDigit() }
        if (plus) return n
        if (n.startsWith("00")) return n.removePrefix("00")
        val cc = editCountry.text.toString().filter { it.isDigit() }
        if (n.startsWith("0") && cc.isNotEmpty()) return cc + n.removePrefix("0")
        return n
    }

    private fun saveContact() {
        val name = editName.text.toString().trim()
        val num = normalizedNumber(editNumber.text.toString())
        if (name.isEmpty() || num.isEmpty()) {
            toast("Enter a name and a number.")
            return
        }
        prefs.edit().putString("country", editCountry.text.toString().trim()).apply()
        val i = contacts.indexOfFirst { it.num == num }
        if (i >= 0) contacts[i] = Contact(name, num) else contacts.add(Contact(name, num))
        persistContacts()
        refreshSpinner(contacts.indexOfFirst { it.num == num } + 1)
        toast("Saved ✓")
    }

    private fun deleteContact() {
        val pos = spinner.selectedItemPosition
        if (pos > 0) {
            contacts.removeAt(pos - 1)
            persistContacts()
            refreshSpinner()
            editName.setText("")
            editNumber.setText("")
            toast("Deleted.")
        }
    }

    // ---------- Photo + OCR ----------

    /** Loads the photo scaled down, rotated upright using EXIF info. */
    private fun loadBitmap(file: File, maxSide: Int): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, bounds)
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide * 2) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val raw = BitmapFactory.decodeFile(file.path, opts)
        val orientation = ExifInterface(file.path)
            .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        val m = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
        }
        val scale = minOf(1f, maxSide.toFloat() / maxOf(raw.width, raw.height))
        m.postScale(scale, scale)
        return Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
    }

    private fun readSerials() {
        if (!hasPhoto) return
        status.text = "Reading serial numbers…"
        val bmp = loadBitmap(photoFile, 2000)
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { result ->
                val found = findSerials(result.text)
                if (found.isEmpty()) {
                    status.text = "No serial numbers found. Retake closer, or type them."
                } else {
                    editSerials.setText(found.joinToString("\n"))
                    status.text = "Found ${found.size}. Please check them against the notes."
                }
            }
            .addOnFailureListener {
                status.text = "Could not read the photo. Try again or type the numbers."
            }
    }

    /**
     * Looks for typical bill serial numbers:
     *  - 1–3 letters + 6–10 digits (+ optional letter/star), e.g. AB1234567, L12345678A
     *  - 8–12 plain digits on a line of their own
     * Adjust these patterns for your currency if needed.
     */
    private fun findSerials(text: String): List<String> {
        val patterns = listOf(
            Regex("""\b[A-Z]{1,3}\s?\d{6,10}\s?[A-Z*]?\b"""),
            Regex("""\b\d{8,12}\b""")
        )
        val out = LinkedHashSet<String>()
        for (line in text.uppercase().lines()) {
            for (p in patterns) {
                p.findAll(line).forEach { out.add(it.value.replace(" ", "")) }
            }
        }
        return out.toList()
    }

    // ---------- Receipt image + WhatsApp ----------

    private fun serialLines(): List<String> =
        editSerials.text.toString().lines().map { it.trim() }.filter { it.isNotEmpty() }

    private fun receiptText(name: String): String {
        val amount = editAmount.text.toString().trim()
        val cur = editCurrency.text.toString().trim()
        val note = editNote.text.toString().trim()
        val serials = serialLines()
        val date = DateFormat.getDateTimeInstance().format(Date())
        return buildString {
            append("Payment receipt\n")
            if (amount.isNotEmpty()) append("Amount: $amount ${cur}\n".replace("  ", " "))
            append("To: $name\nDate: $date")
            if (note.isNotEmpty()) append("\nNote: $note")
            if (serials.isNotEmpty()) append("\nSerial numbers:\n" + serials.joinToString("\n"))
        }
    }

    /** Draws a white receipt strip (amount, name, date, serials) under the photo. */
    private fun buildReceiptImage(name: String): Uri {
        val photo = loadBitmap(photoFile, 1400)
        val w = photo.width
        val fs = maxOf(18f, w * 0.04f)
        val lh = fs * 1.4f
        val serials = serialLines()
        val barH = (lh * (2 + serials.size) + fs).toInt()

        val out = Bitmap.createBitmap(w, photo.height + barH, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawColor(Color.WHITE)
        c.drawBitmap(photo, 0f, 0f, null)

        val amount = editAmount.text.toString().trim()
        val cur = editCurrency.text.toString().trim()
        val note = editNote.text.toString().trim()
        val x = w * 0.04f
        var y = photo.height + fs * 1.2f

        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.BLACK
        p.typeface = Typeface.DEFAULT_BOLD
        p.textSize = fs
        val title = (if (amount.isNotEmpty()) "$amount $cur".trim() else "Payment") + " → " + name
        c.drawText(title, x, y, p)
        y += lh

        p.typeface = Typeface.DEFAULT
        p.color = Color.DKGRAY
        p.textSize = fs * 0.75f
        val date = DateFormat.getDateTimeInstance().format(Date())
        c.drawText(if (note.isNotEmpty()) "$date · $note" else date, x, y, p)
        y += lh

        p.typeface = Typeface.MONOSPACE
        p.color = Color.BLACK
        p.textSize = fs * 0.8f
        serials.forEach {
            c.drawText("S/N $it", x, y, p)
            y += lh
        }

        val file = File(File(cacheDir, "images"), "receipt.jpg")
        FileOutputStream(file).use { out.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        return FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
    }

    private fun sendToWhatsApp() {
        val name = editName.text.toString().trim()
        val num = normalizedNumber(editNumber.text.toString())
        if (num.isEmpty()) {
            toast("Choose or enter a contact first.")
            return
        }
        if (!hasPhoto) {
            toast("Take a photo first.")
            return
        }
        prefs.edit()
            .putString("country", editCountry.text.toString().trim())
            .putString("currency", editCurrency.text.toString().trim())
            .apply()

        val uri = buildReceiptImage(name.ifEmpty { num })
        val text = receiptText(name.ifEmpty { num })

        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "image/jpeg"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, text)
                // Opens the chat with this exact contact (works on most WhatsApp versions)
                putExtra("jid", "$num@s.whatsapp.net")
                setPackage(pkg)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            try {
                startActivity(intent)
                return
            } catch (_: ActivityNotFoundException) {
            }
        }
        // WhatsApp not found: fall back to the normal share sheet.
        val generic = Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, text)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(generic, "Send receipt"))
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
