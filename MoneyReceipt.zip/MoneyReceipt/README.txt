MONEY RECEIPT - Android app (Kotlin)

HOW TO BUILD THE APK
1. Install Android Studio (free): https://developer.android.com/studio
2. Unzip this folder. In Android Studio choose File > Open and select "MoneyReceipt".
3. Wait for "Gradle sync" to finish (needs internet the first time).
4. Plug in your phone (USB debugging on) and press the green Run button,
   or: Build > Build Bundle(s) / APK(s) > Build APK(s), then copy
   app/build/outputs/apk/debug/app-debug.apk to your phone and install it.

HOW IT WORKS
- Contact: pick from phone contacts or type name + number, then Save.
  Enter your country code once (e.g. 251); numbers starting with 0 are converted.
- Photo: takes a picture of the money; serial numbers are read on the phone
  (Google ML Kit, works offline). Edit them if any character is wrong.
- Send: opens WhatsApp directly in that contact's chat with the receipt photo
  and text. You tap Send once (WhatsApp does not allow silent sending).
